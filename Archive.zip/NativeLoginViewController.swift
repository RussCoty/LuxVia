import UIKit
import SafariServices

class NativeLoginViewController: UIViewController {
    
    private let scrollView = UIScrollView()
    private var keyboardVisible = false
    private var originalContentInset: UIEdgeInsets = .zero

    private let logoImageView: UIImageView = {
        let image = UIImage(named: "LuxViaLogo") ?? UIImage()
        let iv = UIImageView(image: image)
        iv.contentMode = .scaleAspectFit
        iv.alpha = 0.0
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()

    private let usernameField = UITextField()
    private let passwordField = UITextField()
    private let loginButton = UIButton(type: .system)
    private let guestButton = UIButton(type: .system)
    private let registerButton = UIButton(type: .system)

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
        animateLogo()
        
        NotificationCenter.default.addObserver(self,
            selector: #selector(keyboardWillShow),
            name: UIResponder.keyboardWillShowNotification,
            object: nil)

        NotificationCenter.default.addObserver(self,
            selector: #selector(keyboardWillHide),
            name: UIResponder.keyboardWillHideNotification,
            object: nil)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        tapGesture.cancelsTouchesInView = false
        view.addGestureRecognizer(tapGesture)


    }
    
    @objc private func dismissKeyboard() {
        view.endEditing(true)
    }

    
    @objc private func keyboardWillShow(notification: NSNotification) {
        guard !keyboardVisible,
              let keyboardFrame = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect else { return }

        keyboardVisible = true
        originalContentInset = scrollView.contentInset

        let bottomInset = keyboardFrame.height + 20
        scrollView.contentInset.bottom = bottomInset
        scrollView.scrollIndicatorInsets.bottom = bottomInset
    }

    @objc private func keyboardWillHide(notification: NSNotification) {
        guard keyboardVisible else { return }

        scrollView.contentInset = originalContentInset
        scrollView.scrollIndicatorInsets = originalContentInset
        keyboardVisible = false
    }

    private func setupUI() {
        usernameField.placeholder = "Username or Email"
        usernameField.borderStyle = .roundedRect

        passwordField.placeholder = "Password"
        passwordField.isSecureTextEntry = true
        passwordField.borderStyle = .roundedRect

        loginButton.setTitle("Login", for: .normal)
        loginButton.addTarget(self, action: #selector(loginTapped), for: .touchUpInside)

        guestButton.setTitle("Try as Guest", for: .normal)
        guestButton.addTarget(self, action: #selector(guestTapped), for: .touchUpInside)

        registerButton.setTitle("Register", for: .normal)
        registerButton.addTarget(self, action: #selector(registerTapped), for: .touchUpInside)

        let formStack = UIStackView(arrangedSubviews: [usernameField, passwordField, loginButton, guestButton, registerButton])
        formStack.axis = .vertical
        formStack.spacing = 12
        formStack.translatesAutoresizingMaskIntoConstraints = false

        let logoContainer = UIView()
        logoContainer.translatesAutoresizingMaskIntoConstraints = false
        logoContainer.addSubview(logoImageView)

        NSLayoutConstraint.activate([
            logoImageView.centerXAnchor.constraint(equalTo: logoContainer.centerXAnchor),
            logoImageView.topAnchor.constraint(equalTo: logoContainer.topAnchor),
            logoImageView.heightAnchor.constraint(equalToConstant: 120),
            logoImageView.widthAnchor.constraint(equalToConstant: 120),
            logoImageView.bottomAnchor.constraint(equalTo: logoContainer.bottomAnchor)
        ])

        let fullStack = UIStackView(arrangedSubviews: [logoContainer, formStack])
        fullStack.axis = .vertical
        fullStack.spacing = 32
        fullStack.translatesAutoresizingMaskIntoConstraints = false

        scrollView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)
        scrollView.addSubview(fullStack)
        
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])

        NSLayoutConstraint.activate([
            fullStack.centerXAnchor.constraint(equalTo: scrollView.centerXAnchor),
            fullStack.topAnchor.constraint(equalTo: scrollView.topAnchor, constant: 60),
            fullStack.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor, constant: 24),
            fullStack.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor, constant: -24),
            fullStack.bottomAnchor.constraint(lessThanOrEqualTo: scrollView.bottomAnchor)
        ])

    }


    private func animateLogo() {
        // Start: hidden, moved up slightly, and scaled down
        logoImageView.alpha = 0.0
        logoImageView.transform = CGAffineTransform(translationX: 0, y: -40).scaledBy(x: 0.8, y: 0.8)

        UIView.animate(withDuration: 2.5,
                       delay: 0.2,
                       usingSpringWithDamping: 0.6,
                       initialSpringVelocity: 1.0,
                       options: [.curveEaseOut],
                       animations: {
            self.logoImageView.alpha = 1.0
            self.logoImageView.transform = .identity
        })
    }


    @objc private func loginTapped() {
        guard let username = usernameField.text, !username.isEmpty,
              let password = passwordField.text, !password.isEmpty else {
            showAlert(message: "Please enter both username and password.")
            return
        }

        let url = URL(string: "https://funeralmusic.co.uk/wp-json/jwt-auth/v1/token")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: String] = ["username": username, "password": password]
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.showAlert(message: "Error: \(error.localizedDescription)")
                }
                return
            }

            guard let data = data,
                  let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                DispatchQueue.main.async {
                    self.showAlert(message: "Invalid response from server.")
                }
                return
            }

            if let token = json["token"] as? String {
                if let tokenData = token.data(using: .utf8) {
                    KeychainHelper.standard.save(tokenData, service: "jwt", account: "funeralmusic")
                }

                UserDefaults.standard.set(true, forKey: "isLoggedIn")
                UserDefaults.standard.set(true, forKey: "isMember")
                UserDefaults.standard.set(false, forKey: "guestMode")

                DispatchQueue.main.async {
                    if let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate {
                        sceneDelegate.showMainApp()
                    }
                }
            } else {
                DispatchQueue.main.async {
                    let message = json["message"] as? String ?? "Login failed"
                    self.showAlert(message: message)
                }
            }
        }

        task.resume()
    }

    @objc private func guestTapped() {
        UserDefaults.standard.set(true, forKey: "isLoggedIn")
        UserDefaults.standard.set(false, forKey: "isMember")
        UserDefaults.standard.set(true, forKey: "guestMode")

        if let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate {
            sceneDelegate.showMainApp()
        }
    }

    @objc private func registerTapped() {
        if let url = URL(string: "https://funeralmusic.co.uk/wp-login.php?action=register") {
            let safariVC = SFSafariViewController(url: url)
            present(safariVC, animated: true)
        }
    }

    private func showAlert(message: String) {
        let alert = UIAlertController(title: "Login", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
