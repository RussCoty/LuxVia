//
//  Notifications+Extensions.swift
//  FuneralMusic
//
//  Created by Russell Cottier on 10/07/2025.
//

import Foundation

 extension Notification.Name {
     static let authStatusChanged = Notification.Name("authStatusChanged")
 }
